
[Latest .apk](https://drive.google.com/file/d/16L3C2JJS7jZN6udIWWCWKvUKZGJzKsXA/view?usp=sharing)

-> Be sure to report any bugs you find!! 

-> Do not use a real password , use a dummy password as well as E-Mail as none if its encrypted. 
