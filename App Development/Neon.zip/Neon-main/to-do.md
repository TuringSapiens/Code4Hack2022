learn -

> Splash Screen!!
> slivers
> learn hash maps
> login with google later??
> why am i getting in null username
> Data cell
> riverpod
> rest API
> flare
> route in main
> about dialog
> cache
> lottie
> bsdk randi discover fix kar jaldi se
> splash screen

where where pice of shit headache post list state is used -

> home page
> neon
> view user post
> discover

karlo bhay pls -

> discover

messages -

> push notification

profile page -

activity -

> push notifications

edit profile -

> check pass that they comply with rules

neons -

> can never neon your own post.

posts -

home page -

> scrolls to the top
> when username click go to user profile
> text going outside screeen

register -

> trim
> how to check if the user enter a $ or #
> chec if mail is taken

sign in -

> remember me

done😀 -

> > // add posts of a person he is bein to the follwer
> > //put everything in one fututre
> > //storage overlapping probably
> > //FutureBuilder
> > //slivers |no can do
> > //uplaoad image
> > //check if a valid username is entered
> > //chec password length
> > //chec if username is tacen
> > //chec if correct pass is entered
> > //enter a valid username
> > //"Push genratates a random value my dude"
> > //read values
> > // list view
> > //builder
> > // circle avatar
> > // wtf are tkens and stuff
> > //stay logged in😀
> > //confirm password
> > //when adding a neon confirm.
> > // poti horahi
> > //enlarge pictures
> > //enlarge pictures
> > //push and forget
> > //show neons and follow
> > //check for time and unseen
> > //?text poti kar rha hai
> > /?chec if correct username is enterd
> > // user profile
> > // on tapping go to post
> > // set name and bio correctly
> > //when like scrooling up
> > //show pass
> > //blur pass
> > // blur password
> > //comments
> > // edit bio
> > //sending space
